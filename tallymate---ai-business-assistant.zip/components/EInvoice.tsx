import React, { useState } from 'react';
import { mockEWayBills } from '../services/mockData';
import { EWayBill } from '../types';
import { Truck, FileCheck, QrCode, Download, Printer, Plus } from 'lucide-react';

const EInvoice: React.FC = () => {
  const [bills, setBills] = useState<EWayBill[]>(mockEWayBills);
  const [showForm, setShowForm] = useState(false);
  const [newBill, setNewBill] = useState<Partial<EWayBill>>({
    date: new Date().toISOString().split('T')[0],
    status: 'Active'
  });
  const [generatedId, setGeneratedId] = useState<string | null>(null);

  const handleGenerate = () => {
    // Simulate API call to GST Portal / E-Invoice Provider
    const generated: EWayBill = {
      id: `ew-${Date.now()}`,
      invoiceNo: newBill.invoiceNo || 'INV-DRAFT',
      date: newBill.date || '',
      partyName: newBill.partyName || 'Unknown Party',
      gstin: newBill.gstin || '29AAAAA0000A1Z5',
      amount: newBill.amount || 0,
      status: 'Active',
      validUntil: '2023-11-05', // Mock validity
      distance: newBill.distance || 0,
      vehicleNo: newBill.vehicleNo || ''
    };

    setTimeout(() => {
      setBills([generated, ...bills]);
      setShowForm(false);
      setGeneratedId(generated.id);
      setNewBill({ date: new Date().toISOString().split('T')[0], status: 'Active' });
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
           <h2 className="text-2xl font-bold text-slate-800">E-Way Bill & E-Invoice</h2>
           <p className="text-slate-500">Generate and manage compliance documents</p>
        </div>
        {!showForm && (
          <button 
            onClick={() => { setShowForm(true); setGeneratedId(null); }}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 transition"
          >
            <Plus size={20} />
            Generate New
          </button>
        )}
      </div>

      {showForm ? (
        <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden max-w-4xl mx-auto">
          <div className="bg-slate-50 px-6 py-4 border-b border-slate-200 flex justify-between items-center">
             <h3 className="font-bold text-slate-800">Generate E-Way Bill</h3>
             <button onClick={() => setShowForm(false)} className="text-sm text-slate-500 hover:text-slate-800">Cancel</button>
          </div>
          
          <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="font-semibold text-slate-700 border-b border-slate-100 pb-2">Invoice Details</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                   <label className="text-xs font-semibold text-slate-500 uppercase">Invoice No</label>
                   <input 
                     type="text" 
                     className="w-full mt-1 border border-slate-300 rounded p-2 text-sm"
                     value={newBill.invoiceNo || ''}
                     onChange={e => setNewBill({...newBill, invoiceNo: e.target.value})}
                   />
                </div>
                <div>
                   <label className="text-xs font-semibold text-slate-500 uppercase">Date</label>
                   <input 
                     type="date" 
                     className="w-full mt-1 border border-slate-300 rounded p-2 text-sm"
                     value={newBill.date || ''}
                     onChange={e => setNewBill({...newBill, date: e.target.value})}
                   />
                </div>
              </div>
              <div>
                   <label className="text-xs font-semibold text-slate-500 uppercase">Party Name</label>
                   <input 
                     type="text" 
                     className="w-full mt-1 border border-slate-300 rounded p-2 text-sm"
                     value={newBill.partyName || ''}
                     onChange={e => setNewBill({...newBill, partyName: e.target.value})}
                   />
              </div>
              <div>
                   <label className="text-xs font-semibold text-slate-500 uppercase">GSTIN</label>
                   <input 
                     type="text" 
                     className="w-full mt-1 border border-slate-300 rounded p-2 text-sm"
                     placeholder="29AAAAA0000A1Z5"
                     value={newBill.gstin || ''}
                     onChange={e => setNewBill({...newBill, gstin: e.target.value})}
                   />
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-semibold text-slate-700 border-b border-slate-100 pb-2">Transporter Details (Part B)</h4>
              <div>
                   <label className="text-xs font-semibold text-slate-500 uppercase">Vehicle Number</label>
                   <input 
                     type="text" 
                     className="w-full mt-1 border border-slate-300 rounded p-2 text-sm"
                     placeholder="KA-01-AB-1234"
                     value={newBill.vehicleNo || ''}
                     onChange={e => setNewBill({...newBill, vehicleNo: e.target.value})}
                   />
              </div>
              <div className="grid grid-cols-2 gap-4">
                 <div>
                   <label className="text-xs font-semibold text-slate-500 uppercase">Distance (KM)</label>
                   <input 
                     type="number" 
                     className="w-full mt-1 border border-slate-300 rounded p-2 text-sm"
                     value={newBill.distance || ''}
                     onChange={e => setNewBill({...newBill, distance: Number(e.target.value)})}
                   />
                 </div>
                 <div>
                   <label className="text-xs font-semibold text-slate-500 uppercase">Total Invoice Amount</label>
                   <input 
                     type="number" 
                     className="w-full mt-1 border border-slate-300 rounded p-2 text-sm font-bold text-slate-700"
                     value={newBill.amount || ''}
                     onChange={e => setNewBill({...newBill, amount: Number(e.target.value)})}
                   />
                 </div>
              </div>
            </div>
          </div>
          
          <div className="p-6 bg-slate-50 border-t border-slate-200 flex justify-end">
             <button 
               onClick={handleGenerate}
               className="bg-green-600 text-white px-8 py-3 rounded-lg font-bold shadow-lg shadow-green-900/10 hover:bg-green-700 transition flex items-center gap-2"
             >
               <FileCheck size={20} />
               Generate E-Way Bill
             </button>
          </div>
        </div>
      ) : (
        /* List View of E-Way Bills */
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {bills.map((bill) => (
             <div key={bill.id} className={`bg-white rounded-xl shadow-sm border ${generatedId === bill.id ? 'border-green-400 ring-2 ring-green-100' : 'border-slate-200'} p-6 relative overflow-hidden transition-all duration-500`}>
                <div className="absolute top-0 right-0 bg-slate-100 p-2 rounded-bl-xl border-l border-b border-slate-200">
                   <QrCode className="text-slate-800" size={32} />
                </div>
                
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                    <Truck size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800">{bill.invoiceNo}</h3>
                    <div className="text-xs text-slate-500">Generated: {bill.date}</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                  <div>
                    <div className="text-slate-400 text-xs">Billed To</div>
                    <div className="font-medium text-slate-800 truncate">{bill.partyName}</div>
                    <div className="text-slate-500 text-xs">{bill.gstin}</div>
                  </div>
                  <div>
                    <div className="text-slate-400 text-xs">Amount</div>
                    <div className="font-bold text-slate-800">₹{bill.amount.toLocaleString()}</div>
                  </div>
                  <div>
                    <div className="text-slate-400 text-xs">Vehicle No</div>
                    <div className="font-medium text-slate-800">{bill.vehicleNo}</div>
                  </div>
                  <div>
                    <div className="text-slate-400 text-xs">Valid Until</div>
                    <div className="font-medium text-red-600">{bill.validUntil}</div>
                  </div>
                </div>

                <div className="flex gap-2 mt-4 pt-4 border-t border-slate-100">
                  <button className="flex-1 py-2 text-sm font-medium text-slate-600 bg-slate-50 hover:bg-slate-100 rounded-lg flex items-center justify-center gap-2">
                    <Download size={16} /> Download
                  </button>
                  <button className="flex-1 py-2 text-sm font-medium text-slate-600 bg-slate-50 hover:bg-slate-100 rounded-lg flex items-center justify-center gap-2">
                    <Printer size={16} /> Print
                  </button>
                </div>
             </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default EInvoice;