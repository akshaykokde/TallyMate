import React, { useState } from 'react';
import { mockLedgers, mockVouchers } from '../services/mockData';
import { VoucherType, Voucher, Ledger } from '../types';
import { Plus, Save, X, Edit2, Trash2 } from 'lucide-react';

const DataEntry: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'vouchers' | 'ledgers'>('vouchers');
  const [isEditing, setIsEditing] = useState(false);
  const [currentVoucher, setCurrentVoucher] = useState<Partial<Voucher>>({});
  const [currentLedger, setCurrentLedger] = useState<Partial<Ledger>>({});
  
  // Local state to simulate data mutation
  const [vouchers, setVouchers] = useState(mockVouchers);
  const [ledgers, setLedgers] = useState(mockLedgers);

  const handleEditVoucher = (voucher: Voucher) => {
    setCurrentVoucher(voucher);
    setIsEditing(true);
  };

  const handleEditLedger = (ledger: Ledger) => {
    setCurrentLedger(ledger);
    setIsEditing(true);
  };

  const handleAddNew = () => {
    if (activeSubTab === 'vouchers') {
      setCurrentVoucher({ 
        date: new Date().toISOString().split('T')[0], 
        type: VoucherType.SALES, 
        status: 'Pending' 
      });
    } else {
      setCurrentLedger({ type: 'Dr', group: 'Sundry Debtors' });
    }
    setIsEditing(true);
  };

  const handleSave = () => {
    if (activeSubTab === 'vouchers') {
      if (currentVoucher.id) {
        setVouchers(vouchers.map(v => v.id === currentVoucher.id ? { ...v, ...currentVoucher } as Voucher : v));
      } else {
        const newVoucher = { 
          ...currentVoucher, 
          id: `v${Date.now()}`,
          referenceNo: `INV-${Math.floor(Math.random() * 1000)}`
        } as Voucher;
        setVouchers([newVoucher, ...vouchers]);
      }
    } else {
      if (currentLedger.id) {
        setLedgers(ledgers.map(l => l.id === currentLedger.id ? { ...l, ...currentLedger } as Ledger : l));
      } else {
        const newLedger = { ...currentLedger, id: `l${Date.now()}` } as Ledger;
        setLedgers([newLedger, ...ledgers]);
      }
    }
    setIsEditing(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
           <h2 className="text-2xl font-bold text-slate-800">Data Entry</h2>
           <p className="text-slate-500">Manage vouchers and ledgers manually</p>
        </div>
        {!isEditing && (
          <button 
            onClick={handleAddNew}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 transition"
          >
            <Plus size={20} />
            Add New {activeSubTab === 'vouchers' ? 'Voucher' : 'Ledger'}
          </button>
        )}
      </div>

      {/* Tabs */}
      {!isEditing && (
        <div className="flex border-b border-slate-200">
          <button 
            className={`px-6 py-3 font-medium text-sm ${activeSubTab === 'vouchers' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
            onClick={() => setActiveSubTab('vouchers')}
          >
            Vouchers
          </button>
          <button 
            className={`px-6 py-3 font-medium text-sm ${activeSubTab === 'ledgers' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
            onClick={() => setActiveSubTab('ledgers')}
          >
            Ledgers
          </button>
        </div>
      )}

      {/* Form View */}
      {isEditing ? (
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 animate-in fade-in slide-in-from-bottom-4">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-bold">
              {activeSubTab === 'vouchers' 
                ? (currentVoucher.id ? 'Edit Voucher' : 'New Voucher') 
                : (currentLedger.id ? 'Edit Ledger' : 'New Ledger')}
            </h3>
            <button onClick={() => setIsEditing(false)} className="text-slate-400 hover:text-slate-600">
              <X size={24} />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {activeSubTab === 'vouchers' ? (
              <>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Date</label>
                  <input 
                    type="date" 
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    value={currentVoucher.date || ''}
                    onChange={e => setCurrentVoucher({...currentVoucher, date: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Voucher Type</label>
                  <select 
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    value={currentVoucher.type || VoucherType.SALES}
                    onChange={e => setCurrentVoucher({...currentVoucher, type: e.target.value as VoucherType})}
                  >
                    {Object.values(VoucherType).map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Party Name</label>
                  <input 
                    type="text" 
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    value={currentVoucher.partyName || ''}
                    onChange={e => setCurrentVoucher({...currentVoucher, partyName: e.target.value})}
                    placeholder="Enter customer/supplier name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Amount</label>
                  <input 
                    type="number" 
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    value={currentVoucher.amount || ''}
                    onChange={e => setCurrentVoucher({...currentVoucher, amount: Number(e.target.value)})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Status</label>
                  <select 
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    value={currentVoucher.status || 'Pending'}
                    onChange={e => setCurrentVoucher({...currentVoucher, status: e.target.value as any})}
                  >
                    <option value="Pending">Pending</option>
                    <option value="Paid">Paid</option>
                    <option value="Overdue">Overdue</option>
                  </select>
                </div>
              </>
            ) : (
              <>
                 <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Ledger Name</label>
                  <input 
                    type="text" 
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    value={currentLedger.name || ''}
                    onChange={e => setCurrentLedger({...currentLedger, name: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Group</label>
                  <select 
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    value={currentLedger.group || 'Sundry Debtors'}
                    onChange={e => setCurrentLedger({...currentLedger, group: e.target.value})}
                  >
                    <option value="Sundry Debtors">Sundry Debtors</option>
                    <option value="Sundry Creditors">Sundry Creditors</option>
                    <option value="Bank Accounts">Bank Accounts</option>
                    <option value="Cash-in-hand">Cash-in-hand</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Opening Balance</label>
                  <input 
                    type="number" 
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    value={currentLedger.balance || ''}
                    onChange={e => setCurrentLedger({...currentLedger, balance: Number(e.target.value)})}
                  />
                </div>
                 <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Type</label>
                  <select 
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    value={currentLedger.type || 'Dr'}
                    onChange={e => setCurrentLedger({...currentLedger, type: e.target.value as any})}
                  >
                    <option value="Dr">Debit</option>
                    <option value="Cr">Credit</option>
                  </select>
                </div>
                 <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Contact No</label>
                  <input 
                    type="text" 
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    value={currentLedger.contact || ''}
                    onChange={e => setCurrentLedger({...currentLedger, contact: e.target.value})}
                  />
                </div>
              </>
            )}
          </div>

          <div className="mt-8 flex gap-3">
            <button 
              onClick={handleSave}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition flex items-center gap-2"
            >
              <Save size={18} />
              Save
            </button>
            <button 
              onClick={() => setIsEditing(false)}
              className="bg-white border border-slate-300 text-slate-700 px-6 py-2 rounded-lg font-medium hover:bg-slate-50 transition"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        /* List View */
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          {activeSubTab === 'vouchers' ? (
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-slate-50 text-slate-500 uppercase font-medium">
                  <tr>
                    <th className="px-6 py-4">Date</th>
                    <th className="px-6 py-4">Ref No</th>
                    <th className="px-6 py-4">Party</th>
                    <th className="px-6 py-4">Type</th>
                    <th className="px-6 py-4 text-right">Amount</th>
                    <th className="px-6 py-4 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {vouchers.map((v) => (
                    <tr key={v.id} className="hover:bg-slate-50 transition cursor-pointer" onClick={() => handleEditVoucher(v)}>
                      <td className="px-6 py-4 text-slate-500">{v.date}</td>
                      <td className="px-6 py-4 font-medium text-slate-800">{v.referenceNo}</td>
                      <td className="px-6 py-4 text-slate-800">{v.partyName}</td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          v.type === VoucherType.SALES ? 'bg-green-100 text-green-700' : 
                          v.type === VoucherType.PURCHASE ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-700'
                        }`}>{v.type}</span>
                      </td>
                      <td className="px-6 py-4 text-right font-bold text-slate-800">₹{v.amount.toLocaleString()}</td>
                      <td className="px-6 py-4 text-center">
                        <button className="p-2 text-slate-400 hover:text-blue-600">
                          <Edit2 size={16} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-slate-50 text-slate-500 uppercase font-medium">
                  <tr>
                    <th className="px-6 py-4">Name</th>
                    <th className="px-6 py-4">Group</th>
                    <th className="px-6 py-4 text-right">Balance</th>
                    <th className="px-6 py-4">Contact</th>
                    <th className="px-6 py-4 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {ledgers.map((l) => (
                    <tr key={l.id} className="hover:bg-slate-50 transition cursor-pointer" onClick={() => handleEditLedger(l)}>
                      <td className="px-6 py-4 font-medium text-slate-800">{l.name}</td>
                      <td className="px-6 py-4 text-slate-500">{l.group}</td>
                      <td className={`px-6 py-4 text-right font-bold ${l.type === 'Dr' ? 'text-green-600' : 'text-red-600'}`}>
                        ₹{l.balance.toLocaleString()} {l.type}
                      </td>
                      <td className="px-6 py-4 text-slate-500">{l.contact}</td>
                      <td className="px-6 py-4 text-center">
                        <button className="p-2 text-slate-400 hover:text-blue-600">
                          <Edit2 size={16} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default DataEntry;