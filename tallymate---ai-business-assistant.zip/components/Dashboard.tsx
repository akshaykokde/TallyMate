import React, { useEffect, useState } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, LineChart, Line 
} from 'recharts';
import { TrendingUp, TrendingDown, Wallet, AlertCircle, Sparkles, Plus, ArrowRight } from 'lucide-react';
import { getFinancialSummary } from '../services/mockData';
import { getSmartInsights } from '../services/geminiService';

interface DashboardProps {
  onNavigate: (tab: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const summary = getFinancialSummary();
  const [insights, setInsights] = useState<string>("Analyzing...");
  const [loadingInsights, setLoadingInsights] = useState(true);

  useEffect(() => {
    const fetchInsights = async () => {
      if (process.env.API_KEY) {
        const text = await getSmartInsights();
        setInsights(text);
      } else {
        setInsights("Connect API Key for insights.");
      }
      setLoadingInsights(false);
    };
    fetchInsights();
  }, []);

  const dataSales = [
    { name: 'Mon', amt: 4000 },
    { name: 'Tue', amt: 3000 },
    { name: 'Wed', amt: 2000 },
    { name: 'Thu', amt: 2780 },
    { name: 'Fri', amt: 1890 },
    { name: 'Sat', amt: 2390 },
    { name: 'Sun', amt: 3490 },
  ];

  const pieData = [
    { name: 'Receivables', value: summary.receivables },
    { name: 'Payables', value: summary.payables },
  ];
  const COLORS = ['#10B981', '#EF4444'];

  return (
    <div className="space-y-6 relative h-full">
      
      {/* Small AI Insight Banner */}
      <div className="bg-indigo-50 border border-indigo-100 rounded-lg p-3 flex items-start md:items-center gap-3 shadow-sm">
        <div className="p-1.5 bg-indigo-100 text-indigo-600 rounded-full shrink-0 mt-0.5 md:mt-0">
          <Sparkles size={16} />
        </div>
        <div className="flex-1 text-sm text-indigo-900">
           {loadingInsights ? (
             <span className="animate-pulse">Gathering insights...</span>
           ) : (
             <span className="line-clamp-2 md:line-clamp-1">{insights}</span>
           )}
        </div>
        <button className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 shrink-0 flex items-center gap-1">
          View All <ArrowRight size={12} />
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-green-100 text-green-600 rounded-lg">
              <Wallet size={20} />
            </div>
            <span className="text-slate-500 text-xs font-medium uppercase">Cash & Bank</span>
          </div>
          <div className="text-2xl font-bold text-slate-800">₹{summary.cashBank.toLocaleString()}</div>
        </div>

        <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-blue-100 text-blue-600 rounded-lg">
              <TrendingUp size={20} />
            </div>
            <span className="text-slate-500 text-xs font-medium uppercase">Total Sales</span>
          </div>
          <div className="text-2xl font-bold text-slate-800">₹{summary.salesTotal.toLocaleString()}</div>
        </div>

        <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-orange-100 text-orange-600 rounded-lg">
              <TrendingDown size={20} />
            </div>
            <span className="text-slate-500 text-xs font-medium uppercase">Receivables</span>
          </div>
          <div className="text-2xl font-bold text-slate-800">₹{summary.receivables.toLocaleString()}</div>
        </div>

        <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-red-100 text-red-600 rounded-lg">
              <AlertCircle size={20} />
            </div>
            <span className="text-slate-500 text-xs font-medium uppercase">Payables</span>
          </div>
          <div className="text-2xl font-bold text-slate-800">₹{summary.payables.toLocaleString()}</div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-20">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <h3 className="font-bold text-slate-800 mb-6">Sales Trend</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={dataSales}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}} 
                />
                <Line type="monotone" dataKey="amt" stroke="#3b82f6" strokeWidth={3} dot={{r: 4, fill: '#3b82f6', strokeWidth: 2, stroke: '#fff'}} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <h3 className="font-bold text-slate-800 mb-6">Outstanding</h3>
          <div className="h-64 flex items-center justify-center">
             <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  fill="#8884d8"
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-6 mt-2">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
              <span className="text-sm text-slate-600">Receivables</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500"></div>
              <span className="text-sm text-slate-600">Payables</span>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Action Button for Data Entry */}
      <button 
        onClick={() => onNavigate('data-entry')}
        className="fixed bottom-6 right-6 w-14 h-14 bg-blue-600 text-white rounded-full shadow-xl shadow-blue-600/30 hover:scale-105 transition-transform flex items-center justify-center z-50 group"
        title="Add Data"
      >
        <Plus size={28} className="group-hover:rotate-90 transition-transform duration-300" />
      </button>

    </div>
  );
};

export default Dashboard;