import React, { useState } from 'react';
import { 
  Menu, X, LayoutDashboard, FileText, Users, Box, 
  Settings, LogOut, RefreshCw, Smartphone, Database, Truck
} from 'lucide-react';
import { mockCompany } from '../services/mockData';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'data-entry', label: 'Data Entry', icon: Database },
    { id: 'einvoice', label: 'E-Way / E-Invoice', icon: Truck },
    { id: 'outstanding', label: 'Outstanding', icon: Users },
    { id: 'reports', label: 'Sales & Purchase', icon: FileText },
    { id: 'stock', label: 'Stock Summary', icon: Box },
    { id: 'bills', label: 'Bill Scanner', icon: Smartphone },
  ];

  return (
    <div className="flex h-screen bg-slate-50">
      {/* Sidebar - Desktop */}
      <aside className="hidden md:flex flex-col w-64 bg-slate-900 text-white">
        <div className="p-5 border-b border-slate-800 flex items-center gap-2">
          <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center font-bold">T</div>
          <span className="text-xl font-bold tracking-tight">TallyMate</span>
        </div>
        
        <div className="p-4 bg-slate-800/50">
          <div className="text-xs text-slate-400 uppercase tracking-wider mb-1">Current Company</div>
          <div className="font-medium truncate">{mockCompany.name}</div>
          <div className="flex items-center gap-1 text-xs text-green-400 mt-1">
            <RefreshCw size={10} />
            Synced: Just now
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                activeTab === item.id 
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' 
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <item.icon size={18} />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-800">
          <button className="flex items-center gap-3 text-slate-400 hover:text-white text-sm w-full px-3 py-2 rounded-lg hover:bg-slate-800 transition">
            <Settings size={18} />
            Settings
          </button>
          <button className="flex items-center gap-3 text-slate-400 hover:text-red-400 text-sm w-full px-3 py-2 rounded-lg hover:bg-slate-800 transition mt-1">
            <LogOut size={18} />
            Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Mobile Header */}
        <header className="md:hidden h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 z-20">
          <div className="flex items-center gap-2">
            <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="text-slate-600">
              {isMobileMenuOpen ? <X /> : <Menu />}
            </button>
            <span className="font-bold text-slate-800">TallyMate</span>
          </div>
          <div className="flex flex-col items-end">
             <span className="text-xs font-semibold text-slate-700 truncate max-w-[150px]">{mockCompany.name}</span>
             <span className="text-[10px] text-green-600">Synced</span>
          </div>
        </header>

        {/* Mobile Menu Overlay */}
        {isMobileMenuOpen && (
          <div className="md:hidden fixed inset-0 z-10 bg-slate-900/95 pt-16 px-4">
            <nav className="space-y-2 mt-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-4 px-4 py-4 rounded-xl text-lg font-medium ${
                    activeTab === item.id ? 'bg-blue-600 text-white' : 'text-slate-400'
                  }`}
                >
                  <item.icon size={24} />
                  {item.label}
                </button>
              ))}
            </nav>
          </div>
        )}

        <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 pb-24 md:pb-6">
          <div className="max-w-6xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;