import React, { useState } from 'react';
import { Camera, Upload, Check, AlertCircle, Loader2 } from 'lucide-react';
import { analyzeBillImage } from '../services/geminiService';

const BillScanner: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleScan = async () => {
    if (!image) return;
    setLoading(true);
    // Remove data:image/...;base64, prefix
    const base64Data = image.split(',')[1];
    const extractedData = await analyzeBillImage(base64Data);
    setResult(extractedData);
    setLoading(false);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold text-slate-800">Smart Bill Entry</h2>
        <p className="text-slate-500">Upload a photo of an invoice or receipt. Gemini AI will extract the details automatically.</p>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
        {!image ? (
          <div className="border-2 border-dashed border-slate-300 rounded-xl p-10 flex flex-col items-center justify-center text-slate-400 gap-4 hover:bg-slate-50 transition cursor-pointer relative">
            <input 
              type="file" 
              accept="image/*" 
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              onChange={handleFileChange}
            />
            <div className="p-4 bg-blue-50 text-blue-600 rounded-full">
              <Camera size={32} />
            </div>
            <div className="text-center">
              <p className="font-medium text-slate-700">Tap to upload or take a photo</p>
              <p className="text-sm">Supports PNG, JPG</p>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="relative rounded-xl overflow-hidden bg-slate-100 max-h-64 flex justify-center">
              <img src={image} alt="Preview" className="h-full object-contain" />
              <button 
                onClick={() => { setImage(null); setResult(null); }}
                className="absolute top-2 right-2 p-1 bg-black/50 text-white rounded-full hover:bg-black/70"
              >
                <AlertCircle size={16} />
              </button>
            </div>

            {!result && (
              <button
                onClick={handleScan}
                disabled={loading}
                className="w-full py-3 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 disabled:opacity-50 transition flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 className="animate-spin" /> : <Upload size={20} />}
                {loading ? 'Processing with AI...' : 'Extract Data'}
              </button>
            )}
          </div>
        )}

        {result && (
          <div className="mt-6 p-4 bg-green-50 border border-green-100 rounded-xl animate-in fade-in slide-in-from-bottom-4">
            <div className="flex items-center gap-2 text-green-700 font-bold mb-3">
              <Check size={20} />
              <span>Extracted Successfully</span>
            </div>
            <pre className="text-xs text-slate-800 bg-white p-4 rounded-lg border border-green-100 overflow-x-auto">
              {result}
            </pre>
            <div className="mt-4 flex gap-3">
                <button className="flex-1 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700">Create Voucher</button>
                <button 
                  onClick={() => { setImage(null); setResult(null); }}
                  className="flex-1 py-2 bg-white border border-slate-300 text-slate-700 text-sm font-medium rounded-lg hover:bg-slate-50"
                >
                  Scan Another
                </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BillScanner;